a = [3, 2, 4, 1, 5, 6,]
a.sort()
print(a)