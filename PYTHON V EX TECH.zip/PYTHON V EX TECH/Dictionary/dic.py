thisdict = { 
 "brand": "BMW", 
 "model": "M6", 
 "year": 2025
} 
thisdict["color"] = "WHITE"
print(thisdict)