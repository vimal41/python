# num = int(input("enter the no.:"))     
# if num%2 == 0:      
# #  print("The given number is an even no.")  




num = int(input("enter the no.:"))           
if num%2 == 0:        
    print("The given number is an even no.")    
else:    
    print("The given Number is an odd no.")    
