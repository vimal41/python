cart = [
    {"item": "Apple", "price": 150},
    {"item": "Banana", "price": 22},
    {"item": "Bread", "price": 22},
    {"item": "Milk", "price": 27},
    {"item": "Eggs", "price": 9}
]

total_price = 0

for item in cart:
    total_price += item["price"]

print("Total_price:", total_price)
