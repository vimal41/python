# def my_function():
#     print("tata, goodbye!")

# my_function()



def my_function(country = ""): 
 print("I am from " + country) 
my_function("India")