
set1 = {"abc", 34, True, 40, "male"} 
myset = {"apple", "banana", "pineapple"} 
print(type(myset))