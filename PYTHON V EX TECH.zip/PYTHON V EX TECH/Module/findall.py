import re 
txt = "The rain in INDIA"
x = re.findall("ai", txt) 
print(x)