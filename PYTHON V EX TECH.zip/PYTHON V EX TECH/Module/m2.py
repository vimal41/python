import my_module
my_module.greeting("vimalvivek")