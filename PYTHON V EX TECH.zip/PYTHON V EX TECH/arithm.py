"""def area_of_rectangle(l,b):
    return l * b
l=2
b=5
area_of_rectangle = l * b

print("area_of_rectangle = "+str(area_of_rectangle))"""
 


import math
r=int(input("enter radius:"))
r=int(input("enter radius:"))
y= math.pi
x=y*(r**2)
print(x)