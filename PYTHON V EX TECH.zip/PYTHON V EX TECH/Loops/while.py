i = 1
while i <= 10:
    print(i)
    i += 1
