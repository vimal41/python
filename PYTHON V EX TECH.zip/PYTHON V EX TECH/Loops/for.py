fruits = ["Apple", "Banana", "pineapple"]
for fruit in fruits:
    print(fruit)
