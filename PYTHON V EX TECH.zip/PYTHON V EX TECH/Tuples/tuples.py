thistuple = ("apple", "banana", "pineapple") 
print(len(thistuple))